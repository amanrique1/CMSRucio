#!/usr/env/bin python
"""
CMSMonitoring: set of utils for CMS monitoring
"""
# Check GH actions
__version__ = "develop"
__all__ = [__version__]
